namespace InvoiceApp.Domain;

// Test-only scheduling seam compiled only in the isolated source copy.
public static class ApprovalInterleaving
{
    public static Action? AfterPendingCheck { get; set; }
}
