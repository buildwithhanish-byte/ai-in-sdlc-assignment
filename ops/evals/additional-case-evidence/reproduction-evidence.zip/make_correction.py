"""Generate the minimal, uninstrumented correction only in the evidence folder."""
from pathlib import Path

here = Path(__file__).resolve().parent
source = (here / 'snapshots/backend/src/InvoiceApp.Domain/ApprovalService.cs').read_text()
for status in ['Approved', 'Rejected']:
    start = source.index(f'        invoice.Status = InvoiceStatus.{status};')
    end = source.index('        return invoice;', start) + len('        return invoice;')
    original = source[start:end]
    replacement = ('        lock (invoice)\n        {\n'
                   '            EnsurePending(invoice);\n\n'
                   + '\n'.join('    ' + line for line in original.splitlines())
                   + '\n        }')
    source = source[:start] + replacement + source[end:]
target = here / 'corrected/ApprovalService.cs'
target.parent.mkdir(exist_ok=True)
with target.open('x', encoding='utf-8') as stream:
    stream.write(source)
print('Created isolated correction: shared invoice monitor and in-lock pending recheck in both decisions.')
