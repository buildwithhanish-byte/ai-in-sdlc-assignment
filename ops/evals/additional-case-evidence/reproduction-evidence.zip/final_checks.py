"""Read-only checks of the project/cases; writes only this evidence summary."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SERVICE = 'backend/src/InvoiceApp.Domain/ApprovalService.cs'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inventory = json.loads((HERE / 'source-inventory.json').read_text())
changed = [name for name, digest in inventory.items() if sha(ROOT / name) != digest]
assert not changed, changed
verification = json.loads((HERE / 'verification.json').read_text())
checks = {}
baseline = (HERE / 'review-base' / SERVICE).read_text()
for number in [11, 12]:
    case = f'case-{number}'
    diff_path = ROOT / f'ops/evals/cases/{case}.diff'
    assert sha(diff_path) == verification['cases'][case]['diff_sha256']
    lines = diff_path.read_text().splitlines(keepends=True)
    hunks = [index for index, line in enumerate(lines) if line.startswith('@@')]
    assert len(hunks) == 1
    index = hunks[0]
    header = re.fullmatch(r'@@ -1,(\d+) \+1,(\d+) @@\n', lines[index])
    assert header is not None
    old = ''.join(line[1:] for line in lines[index + 1:] if line[0] in ' -')
    new = ''.join(line[1:] for line in lines[index + 1:] if line[0] in ' +')
    assert old == baseline
    assert len(old.splitlines()) == int(header[1])
    assert len(new.splitlines()) == int(header[2])
    candidate_path = HERE / f'review-candidates/{case}' / SERVICE
    assert new == candidate_path.read_text()
    assert sha(candidate_path) == verification['cases'][case]['candidate_sha256']
    result = subprocess.run([
        'git', 'apply', '--check',
        '--directory=ops/evals/additional-case-evidence/review-base',
        f'ops/evals/cases/{case}.diff',
    ], cwd=ROOT, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert 'ApprovalInterleaving' not in new
    for prohibited in ['expected classification', 'successes=', 'test run', 'defective', 'corrected counterpart']:
        assert prohibited not in diff_path.read_text().lower()
    checks[case] = {
        'git_apply_check_exit': result.returncode,
        'reconstructed_candidate_matches': True,
        'test_hooks_and_verdicts_absent': True,
    }

test_files = ['ApprovalServiceConcurrencyTests.cs', 'ApprovalInterleaving.cs']
for name in test_files:
    assert sha(HERE / 'runs/original-verified' / name) == sha(HERE / 'runs/corrected-verified' / name)
    assert sha(HERE / name) == sha(HERE / 'runs/corrected-verified' / name)
assert (HERE / 'runs/corrected/INVALID-RUN.txt').exists()
result = {
    'existing_files_checked': len(inventory),
    'existing_files_changed': changed,
    'same_test_and_hook_inputs': True,
    'invalid_attempt_retained_and_excluded': True,
    'patches': checks,
    'review_evaluation_run': False,
}
(HERE / 'final-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
