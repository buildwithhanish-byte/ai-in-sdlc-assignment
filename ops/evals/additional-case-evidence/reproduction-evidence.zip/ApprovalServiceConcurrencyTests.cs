using InvoiceApp.Api;
using InvoiceApp.Domain;
using Xunit;
using Xunit.Abstractions;

namespace InvoiceApp.Tests;

public class ApprovalServiceConcurrencyTests
{
    private readonly ITestOutputHelper _output;

    public ApprovalServiceConcurrencyTests(ITestOutputHelper output) => _output = output;

    [Theory]
    [InlineData("fake", "Approve")]
    [InlineData("in-memory", "Approve")]
    [InlineData("fake", "Reject")]
    [InlineData("in-memory", "Reject")]
    public async Task ConcurrentDecisions_OnlyOneSucceeds(string repositoryKind, string secondDecision)
    {
        const string invoiceId = "INV-CONCURRENCY";
        var invoice = new Invoice
        {
            Id = invoiceId,
            CustomerName = "Synthetic concurrency fixture",
            Amount = 100m,
            Status = InvoiceStatus.PendingApproval
        };
        IInvoiceRepository repository;
        if (repositoryKind == "fake")
        {
            repository = new FakeInvoiceRepository(invoice);
        }
        else
        {
            repository = new InMemoryInvoiceRepository();
            repository.Add(invoice);
        }
        Assert.Same(repository.GetById(invoiceId), repository.GetById(invoiceId));
        var firstService = new ApprovalService(repository);
        var secondService = new ApprovalService(repository);
        using var bothCheckedPending = new Barrier(2);
        var checksReached = 0;
        ApprovalInterleaving.AfterPendingCheck = () =>
        {
            Interlocked.Increment(ref checksReached);
            // Watchdog only; it does not choose a schedule or imply success.
            if (!bothCheckedPending.SignalAndWait(TimeSpan.FromSeconds(15)))
                throw new TimeoutException("Both requests did not reach the scheduling seam.");
        };
        try
        {
            // Dedicated threads avoid thread-pool starvation at the barrier.
            var first = Task.Factory.StartNew(
                () => Capture(() => firstService.Approve(invoiceId, "fixture.first")),
                CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
            var second = Task.Factory.StartNew(
                () => Capture(() => secondDecision == "Approve"
                    ? secondService.Approve(invoiceId, "fixture.second")
                    : secondService.Reject(invoiceId, "fixture.second", "Fixture rejection")),
                CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
            var outcomes = await Task.WhenAll(first, second);
            var successes = outcomes.Count(outcome => outcome == "success");
            var conflicts = outcomes.Count(outcome => outcome == "conflict");
            _output.WriteLine($"Repository={repositoryKind}; second={secondDecision}; " +
                $"outcomes=[{string.Join(", ", outcomes)}]; successes={successes}; conflicts={conflicts}");
            _output.WriteLine($"Final status={invoice.Status}; decidedBy={invoice.DecidedBy}");
            _output.WriteLine($"Scheduling hooks reached={checksReached}");
            Assert.Equal(2, checksReached);
            Assert.Equal(1, successes);
            Assert.Equal(1, conflicts);
            Assert.Equal(outcomes[0] == "success" ? "fixture.first" : "fixture.second", invoice.DecidedBy);
            Assert.Equal(outcomes[0] == "success" || secondDecision == "Approve"
                ? InvoiceStatus.Approved : InvoiceStatus.Rejected, invoice.Status);
        }
        finally
        {
            ApprovalInterleaving.AfterPendingCheck = null;
        }
    }

    private static string Capture(Func<Invoice> decision)
    {
        try
        {
            decision();
            return "success";
        }
        catch (InvalidOperationException)
        {
            return "conflict";
        }
    }
}
