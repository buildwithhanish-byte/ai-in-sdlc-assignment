"""Copy-only reproduction. Never writes application code or prior deliverables."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('--capture', action='store_true')
parser.add_argument('--variant', choices=['original', 'corrected'], default='original')
args = parser.parse_args()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if args.capture:
    if (HERE / 'source-inventory.json').exists():
        raise SystemExit('Snapshot already exists; refusing to replace evidence')
    inventory = {}
    for folder in ['backend', 'e2e', 'docs', 'ops']:
        for path in (ROOT / folder).rglob('*'):
            if not path.is_file() or any(part in ['bin', 'obj', 'node_modules', 'test-results', 'playwright-report'] for part in path.parts):
                continue
            if HERE in path.parents:
                continue
            inventory[path.relative_to(ROOT).as_posix()] = sha(path)
    (HERE / 'source-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
    sources = list((ROOT / 'backend/src/InvoiceApp.Domain').glob('*.cs'))
    sources += [ROOT / item for item in [
        'backend/src/InvoiceApp.Domain/InvoiceApp.Domain.csproj',
        'backend/src/InvoiceApp.Api/InMemoryInvoiceRepository.cs',
        'backend/tests/InvoiceApp.Tests/FakeInvoiceRepository.cs',
        'backend/tests/InvoiceApp.Tests/ApprovalServiceTests.cs',
        'backend/tests/InvoiceApp.Tests/InvoiceApp.Tests.csproj',
    ]]
    for source in sources:
        target = HERE / 'snapshots' / source.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)

domain_source = HERE / 'snapshots/backend/src/InvoiceApp.Domain'
test_source = HERE / 'snapshots/backend/tests/InvoiceApp.Tests'
domain = HERE / 'fixture/Domain'
tests = HERE / 'fixture/Tests'
domain.mkdir(parents=True, exist_ok=True)
tests.mkdir(parents=True, exist_ok=True)
for source in domain_source.iterdir():
    shutil.copyfile(source, domain / source.name)
for name in ['FakeInvoiceRepository.cs', 'ApprovalServiceTests.cs']:
    shutil.copyfile(test_source / name, tests / name)
shutil.copyfile(HERE / 'snapshots/backend/src/InvoiceApp.Api/InMemoryInvoiceRepository.cs', tests / 'InMemoryInvoiceRepository.cs')
project = (test_source / 'InvoiceApp.Tests.csproj').read_text()
project = project.replace('..\\..\\src\\InvoiceApp.Domain\\InvoiceApp.Domain.csproj', '..\\Domain\\InvoiceApp.Domain.csproj')
(tests / 'InvoiceApp.Tests.csproj').write_text(project)
source = (domain / 'ApprovalService.cs').read_text()
if args.variant == 'corrected':
    source = (HERE / 'corrected/ApprovalService.cs').read_text()
# Schedule seam only: after the first successful pending check in each method.
# No changed checks, values, repository semantics or writes.
needle = r'^        EnsurePending\(invoice\);\n\n'
if len(re.findall(needle, source, flags=re.MULTILINE)) != 2:
    raise SystemExit('Unexpected source shape: cannot place the two scheduling hooks')
source = re.sub(needle, '        EnsurePending(invoice);\n        ApprovalInterleaving.AfterPendingCheck?.Invoke();\n\n', source, flags=re.MULTILINE)
(domain / 'ApprovalService.cs').write_text(source)
shutil.copyfile(HERE / 'ApprovalInterleaving.cs', domain / 'ApprovalInterleaving.cs')
shutil.copyfile(HERE / 'ApprovalServiceConcurrencyTests.cs', tests / 'ApprovalServiceConcurrencyTests.cs')
shutil.copyfile(HERE / 'AssemblyInfo.cs', tests / 'AssemblyInfo.cs')
(HERE / 'fixture/preparation.json').write_text(json.dumps({
    'variant': args.variant,
    'service_sha256': sha(domain / 'ApprovalService.cs'),
    'test_sha256': sha(tests / 'ApprovalServiceConcurrencyTests.cs'),
    'hook_sha256': sha(domain / 'ApprovalInterleaving.cs'),
}, indent=2) + '\n')
print(f'Prepared {args.variant} source in isolated fixture; exactly two scheduling hooks inserted.')
