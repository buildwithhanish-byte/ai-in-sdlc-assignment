"""Package review-only diffs after checking the paired reproduction evidence."""
from pathlib import Path
import difflib
import hashlib
import json
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SERVICE = 'backend/src/InvoiceApp.Domain/ApprovalService.cs'
NS = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
HOOK = '        ApprovalInterleaving.AfterPendingCheck?.Invoke();\n'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_run(label, expected_exit, expected_passed, expected_failed):
    run = HERE / 'runs' / label
    metadata = json.loads((run / 'run.json').read_text())
    assert metadata['exit_code'] == expected_exit
    counters = ET.parse(run / 'results.trx').find('.//t:Counters', NS).attrib
    assert int(counters['passed']) == expected_passed, counters
    assert int(counters['failed']) == expected_failed, counters
    output = (run / 'output.txt').read_text()
    assert output.count('Scheduling hooks reached=2') >= 4
    return metadata, counters

original_run, original_counts = check_run('original-verified', 1, 0, 4)
corrected_run, corrected_counts = check_run('corrected-verified', 0, 11, 0)
for name in ['ApprovalServiceConcurrencyTests.cs', 'ApprovalInterleaving.cs']:
    assert original_run['compiled_inputs_sha256'][name] == corrected_run['compiled_inputs_sha256'][name]
    assert sha(HERE / 'runs/original-verified' / name) == sha(HERE / 'runs/corrected-verified' / name)
    assert sha(HERE / name) == sha(HERE / 'runs/corrected-verified' / name)
original = (HERE / 'snapshots' / SERVICE).read_text()
corrected = (HERE / 'corrected/ApprovalService.cs').read_text()
for label, uninstrumented in [('original-verified', original), ('corrected-verified', corrected)]:
    instrumented = (HERE / 'runs' / label / 'ApprovalService.cs').read_text()
    assert instrumented.count(HOOK) == 2
    assert instrumented.replace(HOOK, '') == uninstrumented

# No behavior outside the two decision methods changes in the correction.
def without_decisions(source):
    start = source.index('    public Invoice Approve(')
    end = source.index('    private Invoice Find(', start)
    return source[:start] + source[end:]
assert without_decisions(original) == without_decisions(corrected)

inventory = json.loads((HERE / 'source-inventory.json').read_text())
changed = [name for name, digest in inventory.items() if sha(ROOT / name) != digest]
assert not changed, changed

# Common synthetic baseline: omit only Approve/Reject so their bodies are
# added lines in independent review cases. Include neutral dependency facts
# as context, because reviewers receive only one diff and a prompt.
contract = '''/// In this demo, each request has its own service instance and shares one
/// in-memory repository. GetById returns the same mutable Invoice object for
/// a given ID; repository GetById and Update each lock their own list access.
/// These decision methods operate on submitted invoices. Concurrent decision
/// calls may target the same invoice. Concurrent submission/deletion, external
/// writers and repositories returning detached copies are outside this fixture.
'''
def with_contract(source):
    return source.replace('/// </summary>\n', contract + '/// </summary>\n', 1)
baseline = with_contract(without_decisions(original))
base_path = HERE / 'review-base' / SERVICE
base_path.parent.mkdir(parents=True, exist_ok=True)
with base_path.open('x', encoding='utf-8') as stream:
    stream.write(baseline)
manifest = {}
for number, source in [(11, original), (12, corrected)]:
    candidate = with_contract(source)
    diff = f'diff --git a/{SERVICE} b/{SERVICE}\n' + ''.join(difflib.unified_diff(
        baseline.splitlines(keepends=True), candidate.splitlines(keepends=True),
        fromfile='a/' + SERVICE, tofile='b/' + SERVICE, n=1000))
    assert HOOK.strip() not in diff
    target = ROOT / f'ops/evals/cases/case-{number}.diff'
    with target.open('x', encoding='utf-8') as stream:
        stream.write(diff)
    # Independent apply directory: never apply review cases to the real tree.
    candidate_path = HERE / f'review-candidates/case-{number}' / SERVICE
    candidate_path.parent.mkdir(parents=True, exist_ok=True)
    candidate_path.write_text(candidate)
    manifest[f'case-{number}'] = {
        'diff_sha256': sha(target),
        'candidate_sha256': sha(candidate_path),
        'approve_line': candidate[:candidate.index('    public Invoice Approve(')].count('\n') + 1,
        'reject_line': candidate[:candidate.index('    public Invoice Reject(')].count('\n') + 1,
        'classification': 'defective' if number == 11 else 'clean within the stated fixture contract',
    }
(HERE / 'verification.json').write_text(json.dumps({
    'verified_runs': {'original': original_counts, 'corrected': corrected_counts},
    'identical_test_and_hook_sha256': {
        name: original_run['compiled_inputs_sha256'][name]
        for name in ['ApprovalServiceConcurrencyTests.cs', 'ApprovalInterleaving.cs']
    },
    'hooks_present_in_each_service_copy': 2,
    'instrumentation_only_change_to_original': True,
    'preserved_existing_files': len(inventory),
    'changed_existing_files': changed,
    'cases': manifest,
    'evaluation_run': False,
}, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
print(f'Preserved {len(inventory)} existing files. Test and hook bytes match. No review evaluation run.')
