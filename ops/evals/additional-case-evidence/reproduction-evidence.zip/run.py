"""Run a reproduction test, not a review-model evaluation."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--dotnet', required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--all-tests', action='store_true')
args = parser.parse_args()
preparation = json.loads((HERE / 'fixture/preparation.json').read_text())
for key, path in [
    ('service_sha256', HERE / 'fixture/Domain/ApprovalService.cs'),
    ('test_sha256', HERE / 'fixture/Tests/ApprovalServiceConcurrencyTests.cs'),
    ('hook_sha256', HERE / 'fixture/Domain/ApprovalInterleaving.cs'),
]:
    if hashlib.sha256(path.read_bytes()).hexdigest() != preparation[key]:
        raise SystemExit('Prepared input changed; refusing to run')
if (HERE / 'fixture/Domain/ApprovalService.cs').read_text().count('ApprovalInterleaving.AfterPendingCheck?.Invoke();') != 2:
    raise SystemExit('Both scheduling hooks must be present')
evidence = HERE / 'runs' / args.label
evidence.mkdir(parents=True, exist_ok=False)
command = [args.dotnet, 'test', str(HERE / 'fixture/Tests/InvoiceApp.Tests.csproj'),
           '--logger', 'console;verbosity=detailed',
           '--logger', 'trx;LogFileName=results.trx', '--results-directory', str(evidence)]
if not args.all_tests:
    command += ['--filter', 'FullyQualifiedName~ApprovalServiceConcurrencyTests']
copies = {
    'ApprovalService.cs': HERE / 'fixture/Domain/ApprovalService.cs',
    'ApprovalServiceConcurrencyTests.cs': HERE / 'fixture/Tests/ApprovalServiceConcurrencyTests.cs',
    'ApprovalInterleaving.cs': HERE / 'fixture/Domain/ApprovalInterleaving.cs',
}
hashes = {}
for name, source in copies.items():
    data = source.read_bytes()
    (evidence / name).write_bytes(data)
    hashes[name] = hashlib.sha256(data).hexdigest()
result = subprocess.run(command, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, encoding='utf-8', errors='replace')
(evidence / 'output.txt').write_text(result.stdout, encoding='utf-8')
(evidence / 'run.json').write_text(json.dumps({
    'utc': datetime.now(timezone.utc).isoformat(), 'command': command,
    'exit_code': result.returncode, 'compiled_inputs_sha256': hashes,
    'preparation': preparation,
    'scope': 'instrumented source-copy scheduling test; not an HTTP test or review evaluation'
}, indent=2) + '\n')
print(result.stdout)
print(f'Captured exit code: {result.returncode}; evidence: {evidence}')
sys.exit(result.returncode)
